"""This package is for Quixote to server glue.
"""
